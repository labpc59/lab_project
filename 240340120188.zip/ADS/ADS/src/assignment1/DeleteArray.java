package assignment1;

import java.util.Scanner;

public class DeleteArray {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter no of elements in array : ");
        int number = sc.nextInt();
        int array[] = new int[number];
        
        // Accept array elements
        for (int i = 0; i < array.length; i++) {
            System.out.println("Enter element arr[" + i + "] : ");
            array[i] = sc.nextInt();
        }
        
        // Display array
        System.out.println("Original array:");
        for (int i = 0; i < array.length; i++) {
            System.out.println("arr[" + i + "] : " + array[i]);
        }
        
        // Deletion logic
        System.out.println("Enter array position to delete (0-based index):");
        int position = sc.nextInt();
        
        // Check if the position is valid
        if (position >= 0 && position < array.length) {
            // Shift elements after the deletion point
            for (int i = position; i < array.length - 1; i++) {
                array[i] = array[i + 1];
            }
            
            // Reduce the size of the array by 1
            int[] newArray = new int[array.length - 1];
            System.arraycopy(array, 0, newArray, 0, newArray.length);
            array = newArray;
        } else {
            System.out.println("Invalid position. Please enter a position between 0 and " + (array.length - 1));
        }
        
        // Display modified array
        System.out.println("Modified array:");
        for (int i = 0; i < array.length; i++) {
            System.out.println("arr[" + i + "] : " + array[i]);
        }
    }
}
