
public class DoubleLinkedList {

	static class Node{
		
		int data;
		Node next;
		Node prev;
		public Node(int data) {
			super();
			this.data = data;
			this.next = null;
			this.prev=null;
	}
	Node head;
	Node tail;
	 public void add(int data) {
		 Node newNode=new Node(data);
		 
		 if(head==null) {
			 head=tail=newNode;
		 }
		 else {
			 tail.next=newNode;
			 newNode.prev=tail;
			 tail=newNode;
		 }
	 }
	 
	 public void remove(int data) {
		 if(head==null) return;
			
		 if(head.data==data) {
			 if(head.next==null) {
				 head=null;
				 tail=null;
			 }
			 else {
				 head.next.prev=null;
				head= head.next;
			 }
			 return;
		 }
		 
		 Node current=head;
		 while(current.next!=null && current.data!=data)
		 
		 
	 }
		
	
	
	
	
	
}
}