package assignment3_1;

public class SinglyListOperations {

	public static void main(String[] args) {
		List<Integer> list = new SinglyList<Integer>();
		
		list.addAtFront(5);
		list.addAtFront(10);
		list.addAtFront(15);
		list.addAtRear(20);
		
		list.print();

	}

}
