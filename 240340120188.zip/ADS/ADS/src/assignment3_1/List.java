package assignment3_1;

public interface List<T> {

	void addAtFront(T element);
	void addAtRear(T element);
	T deleteFirstNode();
	boolean isEmpty();
	void print();
}
