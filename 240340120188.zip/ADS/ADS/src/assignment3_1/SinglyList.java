package assignment3_1;

public class SinglyList<T> implements List<T> {

	class Node {
		T data;
		Node next;
	}
	Node head;
	Node tail;
	
	public SinglyList() {
		head=null;
		tail=null;
	}
	@Override
	public void addAtFront(T element) {
		Node newNode = new Node();
		newNode.data = element;
		newNode.next = head;
		head = newNode;
		
		if(tail==null) {
			tail = newNode;
		}
	}

	@Override
	public void addAtRear(T element) {
		Node newNode = new Node();
		newNode.data= element;
		newNode.next= null;
		
		if(isEmpty()) {
			head=newNode;
			tail=newNode;
			return;
		}
		tail.next=newNode;
		tail=newNode;
	}

	@Override
	public T deleteFirstNode() {
		if(head==null) {
			throw new NoDataException("List is empty. Nothing to delete");
		}
		Node temp=head;
		head=head.next;
		
		if(isEmpty()) {
			tail=null;
		}
		return temp.data;
	}

	@Override
	public boolean isEmpty() {
		if(head==null) {
			return true;
		}
		return false;
	}

	@Override
	public void print() {
		Node current = head;
		while(current !=null) {
			System.out.print( " ->  "+current.data);
			current = current.next;
		}
		
	}

}
