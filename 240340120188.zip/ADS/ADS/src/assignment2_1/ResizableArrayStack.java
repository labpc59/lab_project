package assignment2_1;

import java.util.Arrays;

public class ResizableArrayStack<T> implements Stack<T> {
    private T[] elements;
    private int top;

    @SuppressWarnings("unchecked")
	public ResizableArrayStack() {
        this.elements = (T[]) new Object[10]; // Initial capacity
        this.top = -1;
    }

    @Override
    public void push(T element) {
        ensureCapacity();
        elements[++top] = element;
    }

    @Override
    public T pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        T result = elements[top];
        elements[top] = null;
        top--;
        return result;
    }

    @Override
    public T peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return elements[top];
    }

    @Override
    public boolean isEmpty() {
        return top == -1;
    }

    @Override
    public int size() {
        return top + 1;
    }

    private void ensureCapacity() {
        if ((top + 1) > elements.length) {
            elements = Arrays.copyOf(elements, elements.length * 2);//resize
        }
    }
}
