package assignment2_1;

public class StackDemo {

    public static void main(String[] args) {
        // Create a new stack with default initial capacity
        ResizableArrayStack<Integer> stack = new ResizableArrayStack<>();

        // Pushing elements onto the stack
        System.out.println("Pushing elements...");
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Displaying the stack size
        System.out.println("Stack size: " + stack.size());

        // Popping an element from the stack
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);
        int poppedElement1 = stack.pop();
        System.out.println("Popped element: " + poppedElement1);    
        int poppedElement2 = stack.pop();
        System.out.println("Popped element: " + poppedElement2);
      
      

        // Attempting to pop an element from an empty stack
        try {
        	System.out.println("\nAttempting to pop()");
            stack.pop(); // This line will throw an IllegalStateException
        } catch (IllegalStateException e) {
        
            System.out.println( e.getMessage());
        }
    }
}
