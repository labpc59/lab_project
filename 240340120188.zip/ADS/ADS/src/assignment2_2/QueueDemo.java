package assignment2_2;
public class QueueDemo {
    public static void main(String[] args) {
        // Create a queue with initial capacity of 5
        Queue<Integer> queue = new ArrayQueue<>(5);

        // Add elements to the queue
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        queue.enqueue(40);
        queue.enqueue(50);

        System.out.println("Front element is " + queue.peek());

        // Dequeue elements
        System.out.println("Dequeued element is " + queue.dequeue());
        System.out.println("Front element is " + queue.peek());
        System.out.println("Dequeued element is " + queue.dequeue());
        System.out.println("Dequeued element is " + queue.dequeue());
        System.out.println("Dequeued element is " + queue.dequeue());
        System.out.println("Dequeued element is " + queue.dequeue());
 //   System.out.println("Front element after dequeue is " + queue.peek());

        // Check if the queue is empty
        System.out.println("Is queue empty? " + queue.isEmpty());
    }
}
