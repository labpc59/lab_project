package assignment2_2;

public class ArrayQueue<T> implements Queue<T> {
    private Object[] items;
    private int front = 0;
    private int rear = -1;

    public ArrayQueue(int capacity) {	
        items = new Object[capacity];	//5 while object creation
    }

    @Override
    public void enqueue(T item) {
        if (rear == items.length) {
            throw new IllegalStateException("Queue is full");
        }
       
        items[++rear]=item;
       
    }

    @SuppressWarnings("unchecked")
	@Override
    public T dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
		T item = (T) items[front];
       items[front]=null;
       front++;
        return item;
    }

    @SuppressWarnings("unchecked")
	@Override
    public T peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        return (T) items[front];
    }

    @Override
    public boolean isEmpty() {
    	if (front==items.length) 
			return true;
		return false;
    }
}
