#!/bin/bash

# Check if an argument is provided
if [ -z "$1" ]; then
  echo "Usage: $0 <path>"
  exit 1
fi

# Check if the input is a directory
if [ -d "$1" ]; then
  echo "$1 is a directory."
 
else
  echo "$1 is neither a file nor a directory, or it does not exist."
fi
