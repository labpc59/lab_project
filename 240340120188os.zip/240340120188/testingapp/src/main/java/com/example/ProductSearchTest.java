package com.example;

     import org.junit.jupiter.api.AfterEach;
     import org.junit.jupiter.api.BeforeEach;
     import org.junit.jupiter.api.Test;
     import org.openqa.selenium.By;
     import org.openqa.selenium.WebDriver;
     import org.openqa.selenium.WebElement;
     import org.openqa.selenium.chrome.ChromeDriver;
     import org.openqa.selenium.chrome.ChromeOptions;

     import static org.junit.jupiter.api.Assertions.assertTrue;

     public class ProductSearchTest {

         private WebDriver driver;

         @BeforeEach
         public void setUp() {
             // Set the path to the ChromeDriver executable
             System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");

             // Initialize the ChromeDriver
             ChromeOptions options = new ChromeOptions();
             driver = new ChromeDriver(options);

             // Maximize the browser window
             driver.manage().window().maximize();
         }

         @Test
         public void testProductSearch() {
             // Open the target website
             driver.get("https://magento.softwaretestingboard.com/");

             // Find the search box and enter the search term "shirt"
             WebElement searchBox = driver.findElement(By.id("search"));
             searchBox.sendKeys("shirt");

             // Click the search button
             searchBox.submit();

             // Verify the title of the page
             String expectedTitle = "Search results for: 'shirt'";
             assertTrue(driver.getTitle().contains(expectedTitle));
         }

         @AfterEach
         public void tearDown() {
             // Close the browser
             if (driver != null) {
                 driver.quit();
             }
         }
     }