import React, { useState } from 'react';
   import MessageForm from './components/MessageForm';
   import MessageList from './components/MessageList';
   import './App.css';

   const App = () => {
     const [messages, setMessages] = useState([]);

     const addMessage = (message) => {
       setMessages([message, ...messages]);
     };

     const updateMessage = (updatedMessage) => {
       setMessages(messages.map(msg => msg.text === updatedMessage.text ? updatedMessage : msg));
     };

     return (
       <div className="app">
         <h1>Social Media App</h1>
         <MessageForm addMessage={addMessage} />
         <MessageList messages={messages} updateMessage={updateMessage} />
       </div>
     );
   };

   export default App;