import React, { useState } from 'react';

const MessageForm = ({ addMessage }) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message) {
      addMessage({ text: message, likes: 0, dislikes: 0 });
      setMessage('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="message-form">
      <input
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type your message..."
        className="message-input"
      />
      <button type="submit" className="message-submit">Post</button>
    </form>
  );
};

export default MessageForm;
