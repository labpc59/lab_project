import React, { useState } from 'react';

   const MessageItem = ({ message, updateMessage }) => {
     const [likes, setLikes] = useState(message.likes);
     const [dislikes, setDislikes] = useState(message.dislikes);

     const handleLike = () => {
       const newLikes = likes + 1;
       setLikes(newLikes);
       updateMessage({ ...message, likes: newLikes });
     };

     const handleDislike = () => {
       const newDislikes = dislikes + 1;
       setDislikes(newDislikes);
       updateMessage({ ...message, dislikes: newDislikes });
     };

     return (
       <div className="message-item">
         <p>{message.text}</p>
         <div className="buttons">
           <button onClick={handleLike} className="like-button">
             Like ({likes})
           </button>
           <button onClick={handleDislike} className="dislike-button">
             Dislike ({dislikes})
           </button>
         </div>
       </div>
     );
   };

   export default MessageItem;
