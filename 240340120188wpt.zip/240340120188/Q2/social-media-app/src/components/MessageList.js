import React from 'react';
   import MessageItem from './MessageItem';

   const MessageList = ({ messages, updateMessage }) => {
     return (
       <div>
         {messages.map((msg, index) => (
           <MessageItem key={index} message={msg} updateMessage={updateMessage} />
         ))}
       </div>
     );
   };

   export default MessageList;