$(document).ready(function() {
    $('#submitBtn').click(function() {
        let rating = $('#rating').val();
        let starsContainer = $('#stars');
        starsContainer.empty();

        for (let i = 1; i <= 5; i++) {
            if (i <= rating) {
                starsContainer.append('<span class="star filled">&#9733;</span>');
            } else {
                starsContainer.append('<span class="star infilled">&#9733;</span>');
            }
        }
    });

    $(document).on('mouseover', '.star', function() {
        $(this).prevAll().addBack().removeClass('infilled').addClass('hovered');
    }).on('mouseout', '.star', function() {
        $(this).prevAll().addBack().removeClass('hovered');
    });

    $(document).on('click', '.star', function() {
        let index = $(this).index() + 1;
        $('#rating').val(index);
        $('#submitBtn').trigger('click');
    });
});
